/*
	Richard Yoder
	12/1/2015
	Duel 1
*/